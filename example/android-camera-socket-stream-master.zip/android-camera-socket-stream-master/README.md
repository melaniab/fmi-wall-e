# android-camera-socket-stream
Using socket streaming camera video in real time
